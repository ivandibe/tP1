package ar.org.centro8.curso.java.entities;

public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String color, String marca, String modelo, double precio) {
         super(color, marca, modelo, precio);

    }

}