package ar.org.centro8.curso.java.entities;

public class Radio {

    String radio;

    public Radio(String radio) {
        this.radio = radio;
    }

    public String getRadio() {
        return radio;
    }

    public void setRadio(String radio) {
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "Radio [radio=" + radio + "]";
    }

}
