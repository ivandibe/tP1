package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Vehiculo;
import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Radio;

public class TestVehiculoo {

    public static void main(String[] args) {
        Vehiculo v1 = new Vehiculo("gris", "renault", "clio", 15                                                                                    );
        System.out.println(v1);

        AutoClasico c1 = new AutoClasico("amarillo", "fiat", "600", 580);
        System.out.println(c1);
        AutoClasico c2 = new AutoClasico("fucsia", "Renault", "9", 540);
        System.out.println(c2);


        AutoNuevo n1 = new AutoNuevo("negro", "chevrolet", "tracker", 564);
        System.out.println(n1);
        AutoNuevo n2 = new AutoNuevo("rojo", "audi", "TT", 594);
        System.out.println(n2);


        Radio r1 = new Radio("Panasonic");
        System.out.println(r1);
    }
}